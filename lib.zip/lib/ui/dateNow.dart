part of 'ui.dart';

class Datenow extends StatelessWidget {
  String today = DateFormat('yyyy-MM-dd').format(DateTime.now());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Waktu Sekarang')
      ),
      body: Container(
        child: Center(
          child: Text(today),
        )
      ),
    );
  }
}