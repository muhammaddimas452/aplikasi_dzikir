part of 'ui.dart';

class AlQuran extends StatefulWidget {
  @override
  _AlQuranState createState()=> _AlQuranState(); 
}

class _AlQuranState extends State<AlQuran>{
  List dataDariJSON;

  void listSurat(){
    ListSuratViewModel().ambilData().then((value){
      setState(() {
        dataDariJSON = value;
      });
    });
  }  

  @override
  void initState(){
    super.initState();
    listSurat();
  }

  @override
  Widget build (BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text('Al-Quran')
      ),
      body: dataDariJSON == null ? Center(child: CircularProgressIndicator(),) : ListView.builder(
        itemCount: dataDariJSON.length,
        itemBuilder: (context,i){
          return ListTile(
            title: Text(dataDariJSON[i].nama),
            subtitle: Text("${dataDariJSON[i].type} | ${dataDariJSON[i].ayat} ayat"),
            trailing: Text(dataDariJSON[i].asma),
            onTap: (){
              Navigator.push(context, MaterialPageRoute(builder: (context){
                return DetailAlquran(
                  nomor: dataDariJSON[i].nomor,
                  nama : dataDariJSON[i].nama
                );
              }));
            },
          );
        },
      ),
    );
  }
}