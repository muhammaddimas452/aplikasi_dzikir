part of 'ui.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      body: Stack(children: [
        Container(
            height: size.height * .38,
            decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft, 
                  colors: [
                    Color(0xff021c1e),
                    Color(0xff004445),
                    Color(0xff2c7873),
                    Color(0xff6fb98f),
                  ]
                ),
                borderRadius:
                    BorderRadius.only(bottomLeft: Radius.circular(90)))),
        SafeArea(
            child: Padding(
          padding: EdgeInsets.fromLTRB(20, 5, 20, 0),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Align(
                alignment: Alignment.topRight,
                child: Container(
                  height: size.height * .10,
                  width: size.width * .15,
                  child: Image.asset('assets/images/logosmk.png'),
                )),
            Text('Islamic App',
                style: TextStyle(
                    fontSize: 35,
                    fontWeight: FontWeight.bold,
                    color: Colors.white)),
            SizedBox(height: size.height * .02),
            Expanded(
                child: GridView.count(
              crossAxisCount: 2,
              crossAxisSpacing: size.width * .05,
              mainAxisSpacing: size.height * .08,
              children: <Widget>[
                GestureDetector(
                  onTap: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>AlQuran()));
                  },
                  child: Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(13),
                        boxShadow: [
                      BoxShadow(
                        color: Color(0xff8e9b97).withOpacity(0.5),
                        spreadRadius: 8,
                        blurRadius: 7,
                      )
                    ]),
                    child: Column(
                      children: <Widget>[
                        Image.asset('assets/images/quran.png',height: size.height * .15,),
                        Text("Al-Qur'an",style: TextStyle(fontWeight: FontWeight.bold,fontSize:15),)
                      ],
                    ),
                ),
                ),
                 GestureDetector(
                  onTap: (){},
                  child: Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(13),
                        boxShadow: [
                      BoxShadow(
                        color: Color(0xff8e9b97).withOpacity(0.5),
                        spreadRadius: 8,
                        blurRadius: 7,
                      )
                    ]),
                    child: Column(
                      children: <Widget>[
                        Image.asset('assets/images/chronometer.png',height: size.height * .15,),
                        Text("Jadwal Sholat",style: TextStyle(fontWeight: FontWeight.bold,fontSize:15),)
                      ],
                    ),
                ),
                ),
                GestureDetector(
                  onTap: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> Pagi()));
                  },
                  child: Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(13),
                        boxShadow: [
                      BoxShadow(
                        color: Color(0xff8e9b97).withOpacity(0.5),
                        spreadRadius: 8,
                        blurRadius: 7,
                      )
                    ]),
                    child: Column(
                      children: <Widget>[
                        Image.asset('assets/images/sunrise.png',height: size.height * .15,),
                        Text("Dzikir Pagi",style: TextStyle(fontWeight: FontWeight.bold,fontSize:15),)
                      ],
                    ),
                ),
                ),
                GestureDetector(
                  onTap: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> Petang()));
                  },
                  child: Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(13),
                        boxShadow: [
                      BoxShadow(
                        color: Color(0xff8e9b97).withOpacity(0.5),
                        spreadRadius: 8,
                        blurRadius: 7,
                      )
                    ]),
                    child: Column(
                      children: <Widget>[
                        Image.asset('assets/images/night.png',height: size.height * .15,),
                        Text("Dzikir Petang",style: TextStyle(fontWeight: FontWeight.bold,fontSize:15),)
                      ],
                    ),
                ),
                ),
              ],
            ))
          ]),
        ))
      ]),
      bottomNavigationBar: BottomNavigationBar(
        items: const[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Beranda'
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.article),
            label: 'Artikel'
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.money),
            label: 'Donasi'
          ),
        ],
      ),
    );
  }
}
