part of 'ui.dart';

class Locationnow extends StatefulWidget {
  @override
  _LocationnowState createState() => _LocationnowState();
}

class _LocationnowState extends State<Locationnow> {
  String today = DateFormat('yyyy-MM-dd').format(DateTime.now());
  String kota;
  Position datatempat;
  void getPosition() async{
    Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    print(position);

    List<Placemark> placemarks = await placemarkFromCoordinates(position.latitude, position.longitude, localeIdentifier: "id");
    print(placemarks.first.subAdministrativeArea);

    setState(() {
      datatempat = position;
      kota = placemarks.first.subAdministrativeArea;
    });
  }

  Future ambilData() async{
  http.Response hasil = await http.get(
    Uri.encodeFull('https://api.pray.zone/v2/times/day.json?city=${kota}&date=${today}'),
    headers: {"Accept":"application/json"}
  );

  // print(json.encode(hasil.body));
  Map<String, dynamic> map = json.decode(hasil.body);
  print(map['results']['datetime'][0]['times']);
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Lokasi Sekarang')),
      body: Center(
        child: RaisedButton(
          child: Text('Posisi Muncul'),
          onPressed: (){
            getPosition();
          },
        )
      ),
    );
  }
}